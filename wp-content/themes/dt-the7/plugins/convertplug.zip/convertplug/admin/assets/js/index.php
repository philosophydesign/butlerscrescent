<?php
/* Silence is Golden */